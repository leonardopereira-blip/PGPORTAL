const PASTA_CACHE_ID = "1BE3_IL2lfsuFfR3JD1a7Bx7PLtc3Oug-";

function salvarJSONNoDrive(nomeArquivo, dadosObjeto) {
  try {
    var pasta = DriveApp.getFolderById(PASTA_CACHE_ID);
    var conteudoJSON = JSON.stringify(otimizarPayload(dadosObjeto));
    var arquivos = pasta.getFilesByName(nomeArquivo);
    
    if (arquivos.hasNext()) {
      arquivos.next().setContent(conteudoJSON);
    } else {
      pasta.createFile(nomeArquivo, conteudoJSON, MimeType.PLAIN_TEXT);
    }
    return true;
  } catch (e) {
    Logger.log("Erro no cache (" + nomeArquivo + "): " + e.toString());
    return false;
  }
}

function lerJSONDoDrive(nomeArquivo) {
  try {
    var pasta = DriveApp.getFolderById(PASTA_CACHE_ID); 
    var arquivos = pasta.getFilesByName(nomeArquivo);
    
    if (arquivos.hasNext()) {
      return arquivos.next().getBlob().getDataAsString();
    }
    return "[]"; 
  } catch (e) {
    Logger.log("Erro ao ler " + nomeArquivo + ": " + e.toString());
    return "[]";
  }
}

function salvarNoCacheRAM(chave, dados) {
  try {
    var cache = CacheService.getScriptCache();
    var jsonString = (typeof dados === 'string') ? dados : JSON.stringify(dados);
    var maxChars = 45000; 
    var numChunks = Math.ceil(jsonString.length / maxChars);
    var cacheData = {};

    for (var i = 0; i < numChunks; i++) {
      var chunk = jsonString.substring(i * maxChars, (i + 1) * maxChars);
      cacheData[chave + '_chunk_' + i] = chunk;
    }

    cache.putAll(cacheData, 21600); // 6 horas de retenção
    cache.put(chave + '_metadata', numChunks.toString(), 21600);
    return true;
  } catch(e) {
    Logger.log("Erro ao salvar RAM Cache: " + e.toString());
    return false;
  }
}

function lerDoCacheRAM(chave) {
  try {
    var cache = CacheService.getScriptCache();
    var numChunksStr = cache.get(chave + '_metadata');

    if (!numChunksStr) return null; 

    var numChunks = parseInt(numChunksStr, 10);
    var jsonString = "";

    for (var i = 0; i < numChunks; i++) {
      var chunk = cache.get(chave + '_chunk_' + i);
      if (!chunk) return null; 
      jsonString += chunk;
    }

    return jsonString;
  } catch(e) {
    return null;
  }
}

function getDadosDashboard_Cache() {
  var dadosRAM = lerDoCacheRAM('DADOS_DASHBOARD');
  if (dadosRAM && dadosRAM !== "[]") {
    try { return JSON.parse(dadosRAM); } catch(e) { return dadosRAM; }
  }
  
  var dadosDrive = lerJSONDoDrive("cache_dashboard.json");
  if (dadosDrive && dadosDrive !== "[]") {
    salvarNoCacheRAM('DADOS_DASHBOARD', dadosDrive);
    try { return JSON.parse(dadosDrive); } catch(e) { return dadosDrive; }
  }
  
  var dadosFrescos = _processarDadosDashboardBruto();
  var strFresca = JSON.stringify(dadosFrescos);
  salvarNoCacheRAM('DADOS_DASHBOARD', strFresca);
  return dadosFrescos;
}

function atualizarTodoOCache() {
  var dadosPCP = _processarDadosDashboardBruto();
  var jsonPCP = JSON.stringify(otimizarPayload(dadosPCP));
  salvarNoCacheRAM('DADOS_DASHBOARD', jsonPCP);
  salvarJSONNoDrive("cache_dashboard.json", dadosPCP);

  salvarJSONNoDrive("cache_cockpit.json", getDadosCockpit());
  salvarJSONNoDrive("cache_pre_producao.json", getDadosPreProducao());
  salvarJSONNoDrive("cache_qualidade.json", getDadosQualidade());
  salvarJSONNoDrive("cache_ppm.json", getDadosPPM());
  salvarJSONNoDrive("cache_inspecoes.json", getDadosInspecaoCDs());
  salvarJSONNoDrive("cache_alocacao.json", getDadosAlocacao());
  salvarJSONNoDrive("cache_chamados.json", getDadosChamados());
  salvarJSONNoDrive("cache_caixas.json", getDadosCaixas());
  salvarJSONNoDrive("cache_mapa.json", getDadosMapaSaida());
  salvarJSONNoDrive("cache_observacoes.json", buscarHistoricoObsGiro());
}

function getDadosAlocacao_Cache() { return JSON.parse(lerJSONDoDrive("cache_alocacao.json")); }
function getDadosCaixas_Cache() { return JSON.parse(lerJSONDoDrive("cache_caixas.json")); }
function getDadosChamados_Cache() { return JSON.parse(lerJSONDoDrive("cache_chamados.json")); }
function getDadosCockpit_Cache() { return JSON.parse(lerJSONDoDrive("cache_cockpit.json")); }
function getDadosInspecaoCDs_Cache() { return JSON.parse(lerJSONDoDrive("cache_inspecoes.json")); }
function getDadosMapaSaida_Cache() { return JSON.parse(lerJSONDoDrive("cache_mapa.json")); }
function buscarHistoricoObsGiro_Cache() { return JSON.parse(lerJSONDoDrive("cache_observacoes.json")); }
function getDadosPPM_Cache() { return JSON.parse(lerJSONDoDrive("cache_ppm.json")); }
function getDadosPreProducao_Cache() { return JSON.parse(lerJSONDoDrive("cache_pre_producao.json")); }
function getDadosQualidade_Cache() { return JSON.parse(lerJSONDoDrive("cache_qualidade.json")); }

function otimizarPayload(dados) {
  if (!Array.isArray(dados)) return dados;
  return dados.map(function(registro) {
    var limpo = {};
    for (var chave in registro) {
      if (!(String(chave).indexOf("Col") === 0 && registro[chave] === "")) {
        limpo[chave] = registro[chave];
      }
    }
    return limpo;
  });
}








// EXPORTADOR NATIVO GOOGLE SHEETS
function exportarGiroGSheets(dados) {
  try {
    var ss = SpreadsheetApp.create("Giro_Semanal_Pendencias_" + Utilities.formatDate(new Date(), "GMT-3", "dd_MM_yyyy_HHmm"));
    var sheet = ss.getActiveSheet();
    sheet.setName("Pendencias_Giro");
    
    var header = ["Gráfica", "Marca", "Série", "Status Geral", "Etapa Pendente", "Qtd SKUs", "Tiragem Total"];
    sheet.appendRow(header);
    sheet.getRange(1, 1, 1, header.length).setFontWeight("bold").setBackground("#059669").setFontColor("#ffffff");
    
    if (dados && dados.length > 0) {
      var rows = dados.map(function(r) {
        return [r.grafica || "", r.marca || "", r.serie || "", r.status || "", r.pendencia || "", r.qtd || 0, r.tiragemTotal || 0];
      });
      sheet.getRange(2, 1, rows.length, header.length).setValues(rows);
    }
    
    sheet.autoResizeColumns(1, header.length);
    return { success: true, url: ss.getUrl() };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

// =========================================================================
// MÓDULO DE DISPARO DE E-MAIL E CONSOLIDAÇÃO (GIRO SEMANAL) - V3 (SHEETS)
// =========================================================================
function enviarEmailsPendenciasGiro(dados) {
  try {
    // Trava de Segurança no Servidor
    var usuarioAtual = Session.getActiveUser().getEmail();
    if (usuarioAtual && usuarioAtual.toLowerCase() !== "leonardo.pereira@arcoeducacao.com.br") {
      return { success: false, error: "Acesso Negado: Apenas Leonardo Pereira pode disparar estes e-mails." };
    }
    var ssId = "1QqtNrdqJftDYT8LnfiPJmFUWZbkeoPcF2av2wUobxLM";
    var ss = SpreadsheetApp.openById(ssId);
    
    // 1. Limpar e preencher a aba "Pendencias" da linha 2 em diante (Consolidado)
    var abaPend = ss.getSheetByName("Pendencias");
    if (abaPend) {
      var ultimaLinha = abaPend.getLastRow();
      if (ultimaLinha > 1) {
        abaPend.getRange(2, 1, ultimaLinha - 1, abaPend.getLastColumn()).clearContent(); 
      }
      if (dados && dados.length > 0) {
        var linhas = dados.map(function(d) {
          return [d.grafica, d.sku, d.marca, d.serie, d.desc, d.pendencia, d.dias, d.tiragem];
        });
        abaPend.getRange(2, 1, linhas.length, 8).setValues(linhas);
      }
    }
    
    if (!dados || dados.length === 0) return { success: true, count: 0 };

    // 2. Mapear os destinatários da Aba "Email"
    var abaEmail = ss.getSheetByName("Email");
    var mapEmails = {};
    if (abaEmail) {
      var emailsData = abaEmail.getDataRange().getValues();
      for (var i = 1; i < emailsData.length; i++) {
        var g = String(emailsData[i][0]).trim().toUpperCase();
        var e = String(emailsData[i][1]).trim();
        if (g && e) mapEmails[g] = e;
      }
    }
    
    // 3. Agrupar dados por gráfica
    var grupos = {};
    dados.forEach(function(d) {
       var g = String(d.grafica || "N/A").toUpperCase();
       if (!grupos[g]) grupos[g] = { skus: 0, tiragem: 0, itens: [] };
       grupos[g].skus++;
       grupos[g].tiragem += Number(d.tiragem) || 0;
       grupos[g].itens.push(d);
    });
    
    var emailCCMaster = "leonardo.pereira@arcoeducacao.com.br";
    var enviosDisparados = 0;
    
    // 4. Disparar e-mail APENAS para as gráficas mapeadas
    Object.keys(grupos).forEach(function(g) {
        var destinatario = mapEmails[g];
        if (!destinatario) return;
        
        var info = grupos[g];
        
        // 4.1 CRIAR PLANILHA GOOGLE SHEETS EXCLUSIVA PARA A GRÁFICA
        var nomeArquivo = "Backlog_Producao_" + g + "_" + Utilities.formatDate(new Date(), "GMT-3", "dd_MM_yyyy");
        var novaSs = SpreadsheetApp.create(nomeArquivo);
        var novaAba = novaSs.getActiveSheet();
        novaAba.setName("Pendencias");
        
        var cabecalho = ["Gráfica", "SKU", "Marca", "Série", "Descrição", "Etapa Pendente", "Dias de Atraso", "Tiragem"];
        novaAba.appendRow(cabecalho);
        novaAba.getRange(1, 1, 1, cabecalho.length).setFontWeight("bold").setBackground("#0f172a").setFontColor("#ffffff");
        
        // Ordenar itens do mais atrasado pro menos atrasado (negativos)
        info.itens.sort(function(a, b) { return a.dias - b.dias; }); 
        
        var linhasGrafica = info.itens.map(function(item) {
            return [item.grafica, item.sku, item.marca, item.serie, item.desc, item.pendencia, item.dias, item.tiragem];
        });
        
        novaAba.getRange(2, 1, linhasGrafica.length, cabecalho.length).setValues(linhasGrafica);
        novaAba.autoResizeColumns(1, cabecalho.length);
        
        // Tenta compartilhar para qualquer pessoa com o link poder ler
        try { DriveApp.getFileById(novaSs.getId()).setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch(e) {}
        
        var linkPlanilha = novaSs.getUrl();
        
        // 4.2 CONSTRUIR O HTML DO EMAIL
        var html = "<div style='font-family: Arial, sans-serif; color: #333; max-width: 650px; margin: auto; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;'>";
        html += "<div style='background-color: #0f172a; padding: 20px; text-align: center;'><h2 style='color: #ffffff; margin: 0;'>🚨 Relatório de Pendências (Backlog V1)</h2><p style='color: #94a3b8; margin: 5px 0 0 0; font-size: 14px;'>Gráfica: <b>" + g + "</b></p></div>";
        html += "<div style='padding: 20px;'>";
        html += "<p style='font-size: 14px;'>Olá, seguem as pendências de <b>Produção (Envio V1)</b> mapeadas no Backlog que requerem atualização no <b>PCP</b>.</p>";
        
        html += "<div style='display: flex; gap: 15px; margin: 25px 0;'>";
        html += "<div style='flex: 1; background: #f8fafc; padding: 15px; border-radius: 8px; border-left: 4px solid #3b82f6; text-align: center;'><b style='color: #64748b; font-size: 12px; text-transform: uppercase;'>SKUs Atrasados:</b> <span style='font-size: 24px; display: block; color: #1e40af; font-weight: bold; margin-top: 5px;'>" + info.skus + "</span></div>";
        html += "<div style='flex: 1; background: #f8fafc; padding: 15px; border-radius: 8px; border-left: 4px solid #ef4444; text-align: center;'><b style='color: #64748b; font-size: 12px; text-transform: uppercase;'>Tiragem Atrasada:</b> <span style='font-size: 24px; display: block; color: #b91c1c; font-weight: bold; margin-top: 5px;'>" + info.tiragem.toLocaleString('pt-BR') + "</span></div>";
        html += "</div>";

        // Botão para a Planilha do Google
        html += "<div style='text-align: center; margin: 20px 0;'>";
        html += "<a href='" + linkPlanilha + "' style='background-color: #10b981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block; font-size: 14px;'>📊 Acessar Planilha de Pendências</a>";
        html += "</div>";
        
        html += "<h3 style='color: #334155; border-bottom: 1px solid #cbd5e1; padding-bottom: 5px;'>Top 10 Itens Críticos (Por Dias de Atraso):</h3>";
        html += "<table style='width: 100%; border-collapse: collapse; font-size: 11px; text-align: left; margin-top: 10px;'>";
        html += "<tr style='background: #f1f5f9;'><th style='padding: 8px; border-bottom: 2px solid #cbd5e1;'>SKU / Marca</th><th style='padding: 8px; border-bottom: 2px solid #cbd5e1;'>Etapa Pendente</th><th style='padding: 8px; border-bottom: 2px solid #cbd5e1; text-align: center;'>Atraso</th><th style='padding: 8px; border-bottom: 2px solid #cbd5e1; text-align: right;'>Tiragem</th></tr>";
        
        var topItens = info.itens.slice(0, 10);
        topItens.forEach(function(item) {
            html += "<tr style='border-bottom: 1px solid #e2e8f0;'>";
            html += "<td style='padding: 8px; color: #0f172a;'><strong style='display: block;'>" + item.sku + "</strong><span style='color: #64748b; font-size: 9px;'>" + item.marca + " | " + item.serie + "</span></td>";
            html += "<td style='padding: 8px; color: #475569;'>" + item.pendencia + "</td>";
            html += "<td style='padding: 8px; text-align: center; color: #dc2626; font-weight: bold;'>" + item.dias + " d</td>";
            html += "<td style='padding: 8px; text-align: right; font-weight: bold; color: #334155;'>" + Number(item.tiragem).toLocaleString('pt-BR') + "</td>";
            html += "</tr>";
        });
        
        html += "</table>";
        html += "<p style='margin-top: 25px; font-size: 11px; color: #94a3b8; text-align: center; background: #f8fafc; padding: 10px; border-radius: 6px;'>Acesse a planilha no link acima para ver a lista completa de " + info.skus + " SKUs.</p>";
        html += "</div></div>";
        
        MailApp.sendEmail({
            to: destinatario,
            cc: emailCCMaster,
            subject: "🚨 Backlog de Produção Gráfica (V1) - " + g,
            htmlBody: html
        });
        
        enviosDisparados++;
    });
    
    return { success: true, count: enviosDisparados };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}

// =========================================================================
// GERADOR DE PLANILHA - EXATAMENTE O QUE ESTÁ FILTRADO NA TELA
// =========================================================================
function gerarPlanilhaGiroFiltrado(dados) {
  try {
    var nomeArquivo = "Giro_Filtrado_" + Utilities.formatDate(new Date(), "GMT-3", "dd_MM_yyyy_HHmm");
    var ss = SpreadsheetApp.create(nomeArquivo);
    var aba = ss.getActiveSheet();
    aba.setName("Giro_Filtrado");
    
    var cabecalho = ["Gráfica", "Marca", "Série", "SKU", "Descrição", "Status Geral", "Etapa Pendente", "Dias de Atraso", "Tiragem"];
    aba.appendRow(cabecalho);
    aba.getRange(1, 1, 1, cabecalho.length).setFontWeight("bold").setBackground("#0f172a").setFontColor("#ffffff");
    
    // Ordena do mais atrasado (negativo) para o mais positivo
    dados.sort(function(a, b) { return a.dias - b.dias; });
    
    var linhas = dados.map(function(d) {
        return [d.grafica, d.marca, d.serie, d.sku, d.desc, d.status, d.pendencia, d.dias, d.tiragem];
    });
    
    if (linhas.length > 0) {
        aba.getRange(2, 1, linhas.length, cabecalho.length).setValues(linhas);
    }
    aba.autoResizeColumns(1, cabecalho.length);
    
    return { success: true, url: ss.getUrl() };
  } catch(e) {
    return { success: false, error: e.toString() };
  }
}
