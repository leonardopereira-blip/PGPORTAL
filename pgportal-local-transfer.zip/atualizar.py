import os
import re

def atualizar_nomes_e_filtros():
    arquivos_alterados = 0
    
    for root, dirs, files in os.walk('.'):
        for file in files:
            if file.endswith('.html') or file.endswith('.js'):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()

                orig_content = content

                # 1. Trocar "Coleta Mapa" para "Mapa Solicitado" no objeto de FASES
                content = content.replace("nome: 'Coleta Mapa'", "nome: 'Mapa Solicitado'")
                content = content.replace('nome: "Coleta Mapa"', 'nome: "Mapa Solicitado"')

                # 2. Ajustar a lógica do checkbox para garantir que Coleta TP (col_tp) nasça flegado
                # A regex encontra qualquer versão atual da lógica do "isChecked" vinculada a "f.id"
                padrao_checkbox = r"let isChecked\s*=\s*[^;]*f\.id[^;]*\?\s*['\"]['\"]\s*:\s*['\"]checked['\"];"
                novo_checkbox = "let isChecked = (['col', 'tra', 'rec_acab'].includes(f.id)) ? '' : 'checked';"
                
                content = re.sub(padrao_checkbox, novo_checkbox, content)

                if content != orig_content:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(content)
                    print(f"✅ Arquivo atualizado: {file}")
                    arquivos_alterados += 1

    if arquivos_alterados == 0:
        print("⚠️ Nenhuma alteração foi feita. Verifique se os nomes já foram atualizados.")

if __name__ == '__main__':
    print("Aplicando alterações no Funil e nomenclaturas...")
    atualizar_nomes_e_filtros()
    print("Concluído. Execute 'clasp push' no terminal.")